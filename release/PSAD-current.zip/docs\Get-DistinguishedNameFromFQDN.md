﻿---
external help file: PSAD-help.xml
online version: http://msdn.microsoft.com/en-us/library/aa746475.aspx#special_characters
schema: 2.0.0
---

# Get-DistinguishedNameFromFQDN

## SYNOPSIS
TBD

## SYNTAX

```
Get-DistinguishedNameFromFQDN [[-fqdn] <String>]
```

## DESCRIPTION
TBD

## EXAMPLES

### -------------------------- EXAMPLE 1 --------------------------
```
TBD
```

## PARAMETERS

### -fqdn
fqdn explanation

```yaml
Type: String
Parameter Sets: (All)
Aliases: 

Required: False
Position: 1
Default value: [System.DirectoryServices.ActiveDirectory.Domain]::getcurrentdomain()
Accept pipeline input: False
Accept wildcard characters: False
```

## INPUTS

## OUTPUTS

## NOTES

## RELATED LINKS

