﻿---
external help file: PSAD-help.xml
online version: https://github.com/zloeber/PSAD
schema: 2.0.0
---

# Get-DSCurrentConnectedSchema

## SYNOPSIS
Gets the currently connected forest schema information.

## SYNTAX

```
Get-DSCurrentConnectedSchema
```

## DESCRIPTION
Gets the currently connected forest schema information.

## EXAMPLES

### -------------------------- EXAMPLE 1 --------------------------
```
Get-DSCurrentConnectedSchema
```

## PARAMETERS

## INPUTS

## OUTPUTS

## NOTES
Author: Zachary Loeber

## RELATED LINKS

[https://github.com/zloeber/PSAD](https://github.com/zloeber/PSAD)

